<?php 
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBNAME', 'student');


$db_con = mysqli_connect(DBHOST, DBUSER, '', DBNAME);
